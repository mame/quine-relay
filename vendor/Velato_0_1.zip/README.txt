Velato, version 0.1

(c)2009 Daniel Temkin 

(everything except Toub.Sound.Midi)

This is freeware; do with it what you want, just don't sell it.

http://www.rottytooth.com/Velato

